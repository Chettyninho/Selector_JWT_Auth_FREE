<?php
    // En este archivo se validará el jwt pasado por la url cuando se intente acceder a la página

    //redirige a la pagina adecuada si valida el tocken
    add_action('template_redirect', 'jwt_check_protected_page');

   
    function jwt_check_protected_page(){
        //interpreta el post que se trata
        global $post;

        //validamos si es una publicacion y si es una publicacion securizada por JWT
        if (!is_page()) return;
        $is_protected = get_post_meta($post->ID,'_jwt_protect', true);

        //si no está protegida, salimos de la funcion y no validamos nada
        if($is_protected !== '1') return;

        //si esta protegida continua y decodifica el tocken ,
            // - SI ES CORRECTO -> REDIRIGE A LA PAGINA ADECUADA
            // - SI NO ES CORRECTO -> SALTA ERROR

        if(!isset($_GET['token'])){
            wp_die('token no proporcionado, no puedes entrar','Error',['response'=>403]);
        }
        $token = $_GET['token'];
        $tokenParts = explode('.', $token);
        if(count($tokenParts) !== 3 ){
            wp_die('Token mal formado', 'Error', ['response' => 403]);
        }
        $headTokenB64 = $tokenParts[0];
        $payloadTokenB64 = $tokenParts[1];
        $signatureTokenB64 = $tokenParts[2];

        //decodidicamos el encabezado y el cuerpo para tenerlo en un array php
        $header = json_decode(base64_decode(strtr($headTokenB64, '-_', '+/')), true);
        $payload = json_decode(base64_decode(strtr($payloadTokenB64, '-_', '+/')), true);

        //en vez de leerlo de wp-config.php -> crar variable de entorno en el srv para alamacenar ahí la clave secreta sería mejor práctica.
        $secret_key = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : 'clave_por_defecto';   //clave_por_defecto defecto sera invalida siempre pero meh

        //Array asociativo PARA DETERMINAR EL ALGORITMO EN BASE A LA FIRMA SELECCIONADA
        $firma_algoritmo = [
            "HS256" => "sha256",
            "HS384" => "sha384",
            "HS512" => "sha512"
        ];

        //cifrado que viene en el json del token
        $alg = $header['alg'];

        //algoritmo de cifrado general definido en los ajustes del plugin
        $alg_config = get_option( 'jwt_auth_hass_type', 'HS256' );
        
        //si el algoritmo del token no es el especificado en los ajustes del plugin, mata el proceso y salta error.
        if ($alg !== $alg_config) {
            wp_die('Algoritmo no soportado', 'Error', ['response' => 403]);
        }
    
        //genera una firma con el token que han pasado
        $valid_signature = hash_hmac($firma_algoritmo[$alg_config], "$headTokenB64.$payloadTokenB64", $secret_key, true);
        
        //si la firma entregada no coincide con la firma generada, mata el proceso y salta error.
        $valid_signature_b64 = rtrim(strtr(base64_encode($valid_signature), '+/', '-_'), '=');
        if (!hash_equals($signatureTokenB64, $valid_signature_b64)) {
            wp_die('Firma del token inválida', 'Error', ['response' => 403]);
        }
        
        //comprobar fecha de expiracion del token
        if (isset($payload['exp']) && time() > $payload['exp']) {
            wp_die('Token expirado', 'Error', ['response' => 403]);
        }

    }
?>