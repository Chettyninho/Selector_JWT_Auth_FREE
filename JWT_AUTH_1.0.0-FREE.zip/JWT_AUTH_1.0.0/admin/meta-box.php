 <?php
//  ESTABLECER LA METABOX EN LA EDICION DE LA PAGINA PARA ACTIVAR/DESACTIVAR LA VALIDACION POR JWT
 add_action('add_meta_boxes','jwt_add_meta_box');

 function jwt_add_meta_box(){
    add_meta_box(
        'jwt_auth_mb_id',
        'Protección JWT', //titulo
        'jwt_auth_mb_function', //funcion que muestra el contenido de la metabox
        'page', //tipo de publicacion que muestra la meta
        'side', //ubicacion donde se muestra la meta
        'default',
        1
    );
 } 

  //fucnion que generara la meta de si se autenticará o no la página
function jwt_auth_mb_function($post){
    $value = get_post_meta($post->ID,'_jwt_protect',true);

    //crear un campo de verificacion para el metabox
    wp_nonce_field('jwt_auth_meta_box_nonce_action', 'jwt_auth_meta_box_nonce');

    echo '<label for="jwt_protect_checkbox">';
    echo '<input type="checkbox" name="jwt_protect_checkbox" id="jwt_protect_checkbox" value="1" ' . checked($value, '1', false) . ' />';
    echo ' Requiere autenticación JWT';
    echo '</label>';
}

 // Guardar el valor del checkbox al guardar la página
 add_action('save_post', 'jwt_auth_save_meta_box_data');

 function jwt_auth_save_meta_box_data($post_id){
     // Evitar guardados automáticos de la publicacion
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    // Verificar campo al guardar el meta
    if (!isset($_POST['jwt_auth_meta_box_nonce']) || !wp_verify_nonce($_POST['jwt_auth_meta_box_nonce'], 'jwt_auth_meta_box_nonce_action')) {
        return;
    }

    // Verificar permisos del usuario
    if (!current_user_can('edit_post', $post_id)) return;

    // Guardar o eliminar metadato
    if (isset($_POST['jwt_protect_checkbox'])) {
        update_post_meta($post_id, '_jwt_protect', '1');
    } else {
        delete_post_meta($post_id, '_jwt_protect');
    }
 }

 ?>