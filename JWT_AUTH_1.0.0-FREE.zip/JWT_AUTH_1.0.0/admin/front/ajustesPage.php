<?php
echo '<h3>En esta página podrá configurar el plugin para modificar los parámetros a su gusto. </h3>';
$selected = get_option('jwt_auth_hass_type', 'HS256');

echo '<form method="post" action="options.php">';
    settings_fields('ajustes_JWTAuth'); 
    settings_errors();
echo '
    <table class="form-table">
        <tr>
            <th scope="row"><label for="jwt_auth_hass_type">Algoritmo de firma:</label></th>
            <td>
                <select name="jwt_auth_hass_type" id="jwt_auth_hass_type" class="regular-text">
                    <option value="HS256"' . selected($selected, 'HS256', false) . '>HS256</option>
                    <option value="HS384"' . selected($selected, 'HS384', false) . '>HS384</option>
                    <option value="HS512"' . selected($selected, 'HS512', false) . '>HS512</option>
                </select>
            </td>
        </tr>
    </table>
    <p class="submit"><button type="submit" class="button button-primary">Guardar cambios</button></p>
</form>';



echo '<br><br>';
echo '<h2>MEJORAS DE LA VERSIÓN PRO</h2><br>';

echo '<table class="widefat fixed striped">
    <thead>
        <tr>
            <th>Funcionalidad</th>
            <th>Versión Free</th>
            <th>Versión Pro</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Selección de páginas protegidas</td>
            <td>✅ Puedes elegir qué páginas requieren token</td>
            <td>✅ Puedes elegir qué páginas requieren token</td>
        </tr>
        <tr>
            <td>Selección de algoritmo de cifrado global (Se aplicará en todas tus páginas seleccionadas)</td>
            <td>✅ Selección global (HS256, HS384, HS512)</td>
            <td>✅ Selección global (HS256, HS384, HS512)</td>
        </tr>
        <tr>
            <td>Selección de algoritmo específico para cada una de las publicaciones</td>
            <td>❌ No disponible</td>
            <td>✅ Selección específica por página</td>
        </tr>
        <tr>
            <td>Soporte de firmas RSA</td>
            <td>❌ No disponible</td>
            <td>✅ Incluye algoritmos RS256, RS384, RS512</td>
        </tr>
    </tbody>
</table>
';


?>
