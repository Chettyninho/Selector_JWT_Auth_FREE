<?php
add_action( 'admin_init', 'jwt_register_algorithm_setting' );

function jwt_register_algorithm_setting() {
    // Define el grupo de opciones
    $option_group = 'ajustes_JWTAuth';

    // Define el nombre de la opción
    $option_name = 'jwt_auth_hass_type';

    // Registra la opción
    register_setting($option_group, $option_name, [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
    ]);

}

//Menu lateral del plugin
add_action('admin_menu','CrearMenu');

function CrearMenu(){
    add_menu_page(
        'SelectorAuth',
        'SelectorAuth',
        'manage_options',
        'jwtAuthSelector', //slug
        'ContenidoDelPlugin',//funcion del conteido del Plugin 
        plugin_dir_url(__FILE__).'img/jwt_logo.svg',
        '1' //prioridad
    );

    add_submenu_page(
        'jwtAuthSelector', //slug parent
        'Ajustes', //titluo de página (YO AQUI PODRIA METER OTRA URL SI TUVIESE MUCHO CONTENIDO LA PAGINA PARA IR SEPARANDO )
        'Ajustes', //titulo de menu
        'manage_options',
        'ajustes_JWTAuth', //slug
        'SubmenuAjustes' //contenido

    );
}

function CrearSubMenu(){

}

function ContenidoDelPlugin(){
    echo '<h1>'. get_admin_page_title() .'</h1>';
    require_once plugin_dir_path(__FILE__) . 'front/mainPage.php';

}

function SubmenuAjustes(){
    echo '<h1>'. get_admin_page_title() .'</h1>';

        require_once plugin_dir_path(__FILE__) . 'front/ajustesPage.php';
}

?>