=== JWT_Plugin === Colaboradores : Chettyninho Etiquetas : JWT , autenticador , selector
 Requiere al menos : 6.8.1 Probado hasta : 3.9 Requiere PHP : 8.0.26 Licencia : Licencia
 GNU URI : gnu​​​
 
 
 
 


Este complemento permite al administrador seleccionar qué publicaciones solo serán accesibles proporcionando un JWT por URL .

== Descripción == Este complemento permitirá a los administradores de Wordpress seleccionar las publicaciones que deben tener una autenticación de JWT para acceder a ellas , securizando su contenido de forma eficiente y segura . Además el administrador podrá seleccionar el tipo de algoritmo que se usa en cada una de las páginas ( o en todas ) para aumentar la seguridad de cada una en función de su contenido .  



== Instalación == Simplemente copie la carpeta del plug - in en el directorio de plug - ins de su instalación de Wordpres , vaya al administrador y active el mismo  


== Registro de cambios == 1.0 Primera versión  
 