<?php
/*
Plugin Name: Selector JWT Auth
Plugin URI: https://jwt.io
Description: Este plugin está hecho para permitir seleccionar las páginas de Wordpress que queremos que reciban una autenticacion de JWT recibda por URL.
Version: 1.0.1
*/

// Hooks de activación/desactivación
require_once plugin_dir_path(__FILE__) . 'includes/actions.php';
//incluir el menu
require_once plugin_dir_path(__FILE__) . 'admin/menu.php';

//incluir las metabox
require_once plugin_dir_path(__FILE__) . 'admin/meta-box.php';

//Incluir la validacion del token
require_once plugin_dir_path(__FILE__) . 'includes/jwt-check.php';

//cargar el css
add_action('admin_enqueue_scripts', 'jwtAuth_cargar_css');

function jwtAuth_cargar_css($hook) {
    wp_enqueue_style(
        'jwt_auth_selector_css',
        plugin_dir_url(__FILE__) . 'css/admin.css',
        [],
        '1.0.0'
    );
}
?>