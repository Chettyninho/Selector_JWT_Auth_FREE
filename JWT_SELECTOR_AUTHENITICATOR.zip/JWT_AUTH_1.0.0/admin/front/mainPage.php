<?php
//obtendremos todas las páginas de wp
$pages = get_pages();
//lo que se mostrará en el front del plugin
echo '<table class="pagesProtectedInfo">
    <thead>
        <tr class="header_table">
            <td><strong>Página</strong></td>
            <td><strong>Enlace</strong></td>
            <td><strong>Securizada con JWT</strong></td>
        </tr>
    </thead>
    <tbody>';

    foreach($pages as $page){
        $is_protected = get_post_meta($page->ID, '_jwt_protect',true);
        echo '<tr>';
        echo '<td>'. esc_html($page->post_title) . '</td>';
        echo '<td><a href="' . get_edit_post_link($page->ID) . '" target = "_blank">Editar</a></td>';
        echo '<td>' . ($is_protected ? '✅ Sí' : '❌ No') . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
?>

